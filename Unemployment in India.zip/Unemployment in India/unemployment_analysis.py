import pandas as pd

df = pd.read_csv("Unemployment in India.csv")  # ← Use the correct name
print("✅ Dataset loaded successfully")
print(df.head())
# Step 3: Explore the Data
print("📊 Dataset Info:")
print(df.info())

print("\n📌 First 5 Rows:")
print(df.head())

print("\n🔢 Statistical Summary:")
print(df.describe())

print("\n🧩 Column Names:")
print(df.columns)

print("\n🧹 Null Values in Each Column:")
print(df.isnull().sum())
# Step 4: Clean the data

# 1. Remove rows with null values
df.dropna(inplace=True)

# 2. Remove spaces from column names
df.columns = df.columns.str.strip()

# 3. Rename columns for easier access
df.rename(columns={
    'Region': 'State',
    'Date': 'Date',
    'Frequency': 'Frequency',
    'Estimated Unemployment Rate (%)': 'Unemployment_Rate',
    'Estimated Employed': 'Employed',
    'Estimated Labour Participation Rate (%)': 'Labour_Participation_Rate',
    'Area': 'Area'
}, inplace=True)

# 4. Convert 'Date' column to datetime format
df['Date'] = pd.to_datetime(df['Date'])

print("✅ Step 4: Data cleaned successfully!")
print(df.head())
import matplotlib.pyplot as plt
import seaborn as sns

# Set plot style
sns.set(style="whitegrid")

# 📈 Unemployment Rate Over Time
plt.figure(figsize=(12, 6))
sns.lineplot(x='Date', y='Unemployment_Rate', data=df, hue='State', legend=False)
plt.title('📉 Unemployment Rate Over Time by State')
plt.xlabel('Date')
plt.ylabel('Unemployment Rate (%)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
# Step 6: Insights from the data

# Highest Unemployment Rate overall
highest = df[df['Unemployment_Rate'] == df['Unemployment_Rate'].max()]
print("🔺 Highest Unemployment Rate:")
print(highest[['State', 'Date', 'Unemployment_Rate']])

# Lowest Unemployment Rate overall
lowest = df[df['Unemployment_Rate'] == df['Unemployment_Rate'].min()]
print("\n🟢 Lowest Unemployment Rate:")
print(lowest[['State', 'Date', 'Unemployment_Rate']])

# Average Unemployment Rate by State
print("\n📊 Average Unemployment Rate by State:")
print(df.groupby('State')['Unemployment_Rate'].mean().sort_values(ascending=False).head(10))
