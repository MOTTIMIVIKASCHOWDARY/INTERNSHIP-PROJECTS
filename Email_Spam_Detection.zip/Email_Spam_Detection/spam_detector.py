 # spam_detector.py

import pandas as pd

# ✅ Step 2: Load the dataset
df = pd.read_csv("spam.csv", encoding='latin-1')  # Make sure the filename is exactly spam.csv
print("✅ Dataset Loaded Successfully!\n")

# ✅ Step 3: Show the first few rows and columns
print(df.head())
print("\n🧾 Columns in dataset:", df.columns)
# ✅ Step 3: Drop unused columns
df = df[['v1', 'v2']]  # Only keep useful columns
df.columns = ['label', 'message']  # Rename for clarity

print("\n✅ Cleaned dataset:\n")
print(df.head())
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

# Convert labels to binary (0 = ham, 1 = spam)
df['label'] = df['label'].map({'ham': 0, 'spam': 1})

# Vectorize the text messages
X = df['message']
y = df['label']
cv = CountVectorizer()
X_vectorized = cv.fit_transform(X)

# Split into training and test data
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y, test_size=0.2, random_state=42)

# Train the model
model = MultinomialNB()
model.fit(X_train, y_train)

print("\n✅ Model training complete!")
# Predict on test data
y_pred = model.predict(X_test)

# Evaluation results
print("\n🎯 Accuracy:", accuracy_score(y_test, y_pred))
print("\n📄 Classification Report:\n", classification_report(y_test, y_pred))
# Test custom email
test_message = ["Win cash now!!! Click here to claim your prize."]
test_vector = cv.transform(test_message)
prediction = model.predict(test_vector)

print("\n📬 Message:", test_message[0])
print("🔍 Prediction:", "SPAM" if prediction[0] == 1 else "NOT SPAM")
