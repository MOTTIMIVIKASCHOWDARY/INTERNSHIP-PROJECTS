 # Step 2: Import Required Libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

print("✅ Step 2: All libraries imported successfully.")

# Step 3: Load the dataset
df = pd.read_csv("Iris.csv")
df.drop('Id', axis=1, inplace=True)
df.columns = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'species']
df['species'] = df['species'].str.replace('Iris-', '', regex=False)
print("✅ Step 3: Dataset loaded successfully.")
print(df.head())

# 🔁 Step 4: (Temporarily skipped visualization to avoid blocking)
# sns.pairplot(df, hue='species')
# plt.suptitle("Iris Flower Feature Comparison", y=1.02)
# plt.show()

# Step 5: Split the data into training and testing sets
X = df.drop('species', axis=1)  # Features
y = df['species']              # Target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print("✅ Step 5: Data split into training and testing sets.")
print("Training samples:", len(X_train))
print("Testing samples:", len(X_test))

# Step 6: Train the K-Nearest Neighbors (KNN) model
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)

print("✅ Step 6: Model trained successfully.")
# Step 7: Make predictions on test data
y_pred = model.predict(X_test)

print("✅ Step 7: Predictions made successfully.")
print("Predicted labels:", y_pred[:5])
print("Actual labels:   ", y_test.values[:5])
# Step 8: Evaluate model performance
acc = accuracy_score(y_test, y_pred)
print("✅ Step 8: Model evaluation complete.")
print("Accuracy Score:", acc)

print("\n📄 Classification Report:")
print(classification_report(y_test, y_pred))

print("📊 Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
